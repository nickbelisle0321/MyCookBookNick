﻿// recipe.js

document.addEventListener("DOMContentLoaded", function () {
    const BASE_URL = "https://localhost:7182/api/Recipe";
    let selectedCategories = [];
    let selectedEditCategories = [];

    const categoryMapping = {
        0: "Breakfast",
        1: "Lunch",
        2: "Dinner",
        3: "Dessert",
        4: "Snack",
        5: "Vegan",
        6: "Vegetarian",
        7: "GlutenFree",
        8: "Keto",
        9: "LowCarb",
        10: "HighProtein"
    };

    console.log("Page loaded, fetching recipes...");
    fetchRecipes();

    function fetchRecipes() {
        fetch(`${BASE_URL}/GetAll`)
            .then(response => response.json())
            .then(data => {
                data.forEach(r => {
                    r.categories = (r.categories || []).map(c => typeof c === "number" ? categoryMapping[c] : c);
                });
                displayRecipes(data);
            })
            .catch(err => console.error("Fetch error:", err));
    }

    function displayRecipes(recipes) {
        const container = document.getElementById("recipeCards");
        container.innerHTML = "";

        recipes.forEach(recipe => {
            const categoriesText = (recipe.categories || []).join(" | ");
            const card = document.createElement("div");
            card.classList.add("mb-3");
            card.innerHTML = `
                <div class="card shadow-sm">
                    <div class="card-body">
                        <div class="d-flex justify-content-between align-items-center mb-2">
                            <div>
                                <h5 class="card-title mb-0">${recipe.name}</h5>
                                <p class="text-muted mb-0">${recipe.tagLine || ""}</p>
                            </div>
                            <div>
                                <button class="btn btn-warning btn-sm edit-btn" data-id="${recipe.recipeId}">Edit</button>
                                <button class="btn btn-danger btn-sm" onclick="deleteRecipe('${recipe.recipeId}')">Delete</button>
                            </div>
                        </div>
                        <p>${recipe.summary}</p>
                        <p><strong>Ingredients:</strong> ${recipe.ingredients.join(", ")}</p>
                        <p><strong>Instructions:</strong> ${recipe.instructions.join("<br>")}</p>
                    </div>
                    <div class="card-footer">
                        <b>Categories:</b> ${categoriesText}
                    </div>
                </div>`;
            container.appendChild(card);
        });

        const editButtons = container.querySelectorAll(".edit-btn");
        editButtons.forEach(btn => {
            btn.addEventListener("click", function () {
                const recipeId = this.getAttribute("data-id");
                editRecipe(recipeId);
            });
        });
    }

    function handleEnter(event) {
        if (event.key === "Enter") {
            event.preventDefault();
            searchRecipes();
        }
    }

    function toggleClearButton() {
        const input = document.getElementById("searchInput");
        const clearBtn = document.getElementById("clearSearch");
        if (input && clearBtn) {
            clearBtn.style.display = input.value ? "inline" : "none";
        }
    }

    window.clearSearch = function () {
        const input = document.getElementById("searchInput");
        if (input) {
            input.value = "";
            toggleClearButton();
            fetchRecipes();
        }
    };

    function searchRecipes() {
        const input = document.getElementById("searchInput");
        if (!input) return;

        const query = input.value.trim();

        fetch(`${BASE_URL}/Search`, {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
                Accept: "application/json"
            },
            body: JSON.stringify({
                keyword: query,
                categories: []
            })
        })
            .then(response => response.json())
            .then(data => {
                updateSearchResults(data);
            })
            .catch(error => console.error("Search error:", error));
    }

    function updateSearchResults(recipes) {
        let resultsContainer = document.getElementById("searchResults");
        let allRecipesContainer = document.getElementById("allRecipes");

        resultsContainer.innerHTML = "";
        allRecipesContainer.style.display = "none";

        if (recipes.length === 0) {
            resultsContainer.innerHTML = "<p class='text-center'>No matching recipes found.</p>";
            return;
        }

        recipes.forEach(recipe => {
            let recipeCard = `
                <div class="col-md-6 mb-4">
                    <div class="card">
                        <div class="card-body">
                            <h5 class="card-title">${recipe.name}</h5>
                            <p class="card-text"><strong>Ingredients:</strong> ${recipe.ingredients.join(", ")}</p>
                            <p class="card-text"><strong>Steps:</strong> ${recipe.instructions.join("<br>")}</p>
                        </div>
                    </div>
                </div>
            `;
            resultsContainer.innerHTML += recipeCard;
        });
    }

    setTimeout(() => {
        const saveRecipeBtn = document.getElementById("saveRecipe");
        if (saveRecipeBtn) {
            saveRecipeBtn.addEventListener("click", function (event) {
                event.preventDefault();
                console.log("🚀 Save Recipe button clicked!");

                const recipe = {
                    name: document.getElementById("recipeName").value.trim(),
                    tagLine: document.getElementById("tagLine").value.trim(),
                    summary: document.getElementById("summary").value.trim(),
                    ingredients: document.getElementById("ingredients").value.split(",").map(i => i.trim()),
                    instructions: document.getElementById("instructions").value.split("\n").map(i => i.trim()),
                    categories: selectedCategories.map(id => categoryMapping[id])
                };

                console.log("📦 Recipe object to be sent:", recipe);

                fetch(`${BASE_URL}/Add`, {
                    method: "POST",
                    headers: { "Content-Type": "application/json" },
                    body: JSON.stringify(recipe)
                })
                    .then(response => {
                        if (!response.ok) throw new Error("Server error: " + response.status);
                        return response.json();
                    })
                    .then(data => {
                        console.log("✅ Server response:", data);
                        if (data.success) {
                            alert("Recipe added successfully!");

                            // ✅ Manually close modal here
                            const modal = bootstrap.Modal.getInstance(document.getElementById("addRecipeModal"));
                            if (modal) modal.hide();

                            fetchRecipes();
                        } else {
                            alert(data.message || "Failed to add recipe.");
                        }
                    })
                    .catch(error => {
                        console.error("❌ Error adding recipe:", error);
                        alert("Failed to add recipe. " + error.message);
                    });
            });

        }
    }, 300);

    const updateBtn = document.getElementById("updateRecipe");
    if (updateBtn) {
        updateBtn.addEventListener("click", function (event) {
            event.preventDefault();
            updateRecipe();
        });
    }

    window.updateRecipe = function () {
        const recipeId = document.getElementById("editRecipeId").value.trim();
        const updatedRecipe = {
            recipeId,
            name: document.getElementById("editRecipeName").value.trim(),
            tagLine: document.getElementById("editTagLine").value.trim(),
            summary: document.getElementById("editSummary").value.trim(),
            ingredients: document.getElementById("editIngredients").value.split(",").map(i => i.trim()),
            instructions: document.getElementById("editInstructions").value.split("\n").map(i => i.trim()),
            categories: JSON.parse(document.getElementById("editCategories").value || "[]"),
            media: []
        };

        fetch(`${BASE_URL}/${recipeId}`, {
            method: "PUT",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(updatedRecipe)
        })
            .then(response => {
                if (!response.ok) {
                    return response.text().then(text => {
                        throw new Error(`Error ${response.status}: ${text}`);
                    });
                }
                if (response.status === 204) return null;
                return response.json();
            })
            .then(data => {
                alert("Recipe updated successfully!");
                const modal = bootstrap.Modal.getInstance(document.getElementById("editRecipeModal"));
                if (modal) modal.hide();
                fetchRecipes();
            })
            .catch(error => {
                console.error("❌ Error updating recipe:", error);
                alert("Failed to update recipe: " + error.message);
            });
    };

    window.editRecipe = function (recipeId) {
        fetch(`${BASE_URL}/${recipeId}`)
            .then(response => response.json())
            .then(recipe => {
                document.getElementById("editRecipeId").value = recipe.recipeId;
                document.getElementById("editRecipeName").value = recipe.name;
                document.getElementById("editTagLine").value = recipe.tagLine || "";
                document.getElementById("editSummary").value = recipe.summary || "";
                document.getElementById("editIngredients").value = (recipe.ingredients || []).join(", ");
                document.getElementById("editInstructions").value = (recipe.instructions || []).join("\n");

                selectedEditCategories = (recipe.categories || []).map(cat =>
                    parseInt(Object.keys(categoryMapping).find(key => categoryMapping[key] === cat))
                );
                document.getElementById("editCategories").value = JSON.stringify(selectedEditCategories);

                const dropdownItems = document.querySelectorAll("#editCategoryList .dropdown-item");
                dropdownItems.forEach(item => {
                    const value = parseInt(item.getAttribute("data-value"));
                    item.classList.toggle("active", selectedEditCategories.includes(value));
                });

                document.getElementById("editCategoryDropdown").innerText = selectedEditCategories.map(id => categoryMapping[id]).join(", ") || "Select Categories";

                const modal = new bootstrap.Modal(document.getElementById("editRecipeModal"));
                modal.show();
            })
            .catch(error => console.error("Error fetching recipe:", error));
    };

    const addRecipeBtn = document.getElementById("addRecipeBtn");
    if (addRecipeBtn) {
        addRecipeBtn.addEventListener("click", () => {
            selectedCategories = [];
            document.getElementById("addRecipeForm").reset();
            document.getElementById("categories").value = JSON.stringify([]);
            document.getElementById("categoryDropdown").innerText = "Select Categories";

            const dropdownItems = document.querySelectorAll("#categoryList .dropdown-item");
            dropdownItems.forEach(item => item.classList.remove("active"));

            const modal = new bootstrap.Modal(document.getElementById("addRecipeModal"));
            modal.show();
        });
    }

    const categoryItems = document.querySelectorAll("#categoryList .dropdown-item");
    categoryItems.forEach(item => {
        item.addEventListener("click", function (event) {
            event.preventDefault();
            const value = parseInt(this.getAttribute("data-value"));

            if (selectedCategories.includes(value)) {
                selectedCategories = selectedCategories.filter(v => v !== value);
                this.classList.remove("active");
            } else {
                selectedCategories.push(value);
                this.classList.add("active");
            }

            document.getElementById("categories").value = JSON.stringify(selectedCategories);
            document.getElementById("categoryDropdown").innerText =
                selectedCategories.length > 0
                    ? selectedCategories.map(id => categoryMapping[id]).join(", ")
                    : "Select Categories";
        });
    });

    window.deleteRecipe = function (recipeId) {
        if (!confirm("Are you sure you want to delete this recipe?")) return;

        fetch(`${BASE_URL}/${recipeId}`, {
            method: "DELETE"
        })
            .then(async response => {
                if (response.status === 204) {
                    fetchRecipes();
                    return;
                }

                const text = await response.text();
                if (!text) {
                    fetchRecipes();
                    return;
                }

                const data = JSON.parse(text);

                if (data.success) {
                    fetchRecipes();
                } else {
                    alert("Failed to delete recipe: " + (data.message || "Unknown error"));
                }
            })
            .catch(error => {
                console.error("❌ Error deleting recipe:", error);
                alert("Failed to delete recipe: " + error.message);
            });
    };
});
