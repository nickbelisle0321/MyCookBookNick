using MyCookBookApp.Services;

var builder = WebApplication.CreateBuilder(args);

// Add MVC and HTTP client to call the API
builder.Services.AddControllersWithViews();

builder.Services.AddHttpClient<RecipeService>(client =>
{
    client.BaseAddress = new Uri("https://localhost:7182"); // This must match the API project's base URL
});

// CORS (optional for app, but included for completeness)
builder.Services.AddCors(options =>
{
    options.AddPolicy("AllowAll", policy =>
        policy.AllowAnyOrigin()
              .AllowAnyMethod()
              .AllowAnyHeader());
});

var app = builder.Build();

if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error");
    app.UseHsts();
}

// CORS (optional unless you're serving from a different port/domain)
app.UseCors("AllowAll");

app.UseHttpsRedirection(); // Recommended for security
app.UseStaticFiles();
app.UseRouting();
app.UseAuthorization();

// Default route for MVC
app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Recipe}/{action=Index}/{id?}");

app.Run();
