﻿using Microsoft.AspNetCore.Mvc;
using MyCookBookApp.Services;
using System.Threading.Tasks;
using System.Collections.Generic;
using Newtonsoft.Json;
using MyCookBookApp.Models;

namespace MyCookBookApp.Controllers
{
    [Route("Recipe")]
    public class RecipeController : Controller
    {
        private readonly RecipeService _recipeService;

        public RecipeController(RecipeService recipeService)
        {
            _recipeService = recipeService;
        }

        // ✅ FIX: Load recipes for Index view
        [HttpGet("")]
        public async Task<IActionResult> Index()
        {
            var recipes = await _recipeService.GetRecipesAsync();
            return View(recipes); // Pass recipes directly to the view
        }

        [HttpGet("GetAll")]
        public async Task<IActionResult> GetAllRecipes()
        {
            var recipes = await _recipeService.GetRecipesAsync();
            return Json(recipes);
        }

        [HttpGet("{id}")]
        public async Task<IActionResult> GetRecipeById(string id)
        {
            var recipe = await _recipeService.GetRecipeByIdAsync(id);
            if (recipe == null)
            {
                return NotFound(new
                {
                    success = false,
                    message = "Recipe not found"
                });
            }
            return Json(recipe);
        }

        [HttpPost("Search")]
        public async Task<IActionResult> SearchRecipes([FromBody] RecipeSearchRequest searchRequest)
        {
            var recipes = await _recipeService.SearchRecipesAsync(searchRequest);
            return Json(recipes);
        }

        [HttpPost("Add")]
        public async Task<IActionResult> AddRecipe([FromBody] Recipe recipe)
        {
            Console.WriteLine("Received Recipe: " + JsonConvert.SerializeObject(recipe));

            if (recipe == null || string.IsNullOrWhiteSpace(recipe.Name) ||
                recipe.Ingredients == null || recipe.Ingredients.Count == 0 ||
                recipe.Instructions == null || recipe.Instructions.Count == 0 ||
                string.IsNullOrWhiteSpace(recipe.Summary))
            {
                return BadRequest(new
                {
                    success = false,
                    message = "Invalid recipe data"
                });
            }

            if (string.IsNullOrEmpty(recipe.RecipeId))
                recipe.RecipeId = Guid.NewGuid().ToString();

            bool added = await _recipeService.AddRecipeAsync(recipe);

            return Json(new
            {
                success = added,
                message = added ? "Recipe added successfully" : "Failed to add recipe",
                recipe
            });
        }

        [HttpPut("Edit/{id}")]
        public async Task<IActionResult> EditRecipe(string id, [FromBody] Recipe recipe)
        {
            if (recipe == null || string.IsNullOrWhiteSpace(recipe.Name) ||
                recipe.Ingredients == null || recipe.Ingredients.Count == 0 ||
                recipe.Instructions == null || recipe.Instructions.Count == 0 ||
                string.IsNullOrWhiteSpace(recipe.Summary) || recipe.Categories == null)
            {
                return BadRequest(new { success = false, message = "Invalid recipe data" });
            }

            bool updated = await _recipeService.UpdateRecipeAsync(recipe);
            return Json(new { success = updated, message = updated ? "Recipe updated successfully" : "Failed to update recipe" });
        }
    }
}
