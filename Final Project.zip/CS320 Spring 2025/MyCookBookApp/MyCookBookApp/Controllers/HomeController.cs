using Microsoft.AspNetCore.Mvc;
using MyCookBookApp.Models;
using MyCookBookApp.Services;
using System.Diagnostics;

namespace MyCookBookApp.Controllers
{
    public class HomeController : Controller
    {
        private readonly RecipeService _recipeService;

        public HomeController(RecipeService recipeService)
        {
            _recipeService = recipeService;
        }

        // Make this the default action (used for homepage)
        public async Task<IActionResult> Index()
        {
            var recipes = await _recipeService.GetRecipesAsync();
            return View("HomePage", recipes);
        }

        //  Do NOT route this to root � just "/Home/About"
        public IActionResult About()
        {
            return View();
        }
    }

}
