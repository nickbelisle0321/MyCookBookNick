﻿document.addEventListener("DOMContentLoaded", function () {
    const BASE_URL = "https://localhost:7182/api/Recipe";
    let selectedCategories = [];
    let selectedEditCategories = [];

    const categoryMapping = {
        0: "Breakfast", 1: "Lunch", 2: "Dinner", 3: "Dessert", 4: "Snack",
        5: "Vegan", 6: "Vegetarian", 7: "GlutenFree", 8: "Keto",
        9: "LowCarb", 10: "HighProtein"
    };

    fetchRecipes();

    function fetchRecipes() {
        fetch(`${BASE_URL}/GetAll`)
            .then(res => res.json())
            .then(data => {
                data.forEach(r => {
                    r.categories = (r.categories || []).map(c => typeof c === "number" ? categoryMapping[c] : c);
                });
                displayRecipes(data);
            })
            .catch(err => console.error("❌ Fetch error:", err));
    }

    function displayRecipes(recipes) {
        const container = document.getElementById("allRecipes");
        const searchResults = document.getElementById("searchResults");

        if (!container) {
            console.warn("⚠️ No #allRecipes container found.");
            return;
        }

        container.innerHTML = "";
        searchResults.innerHTML = "";
        container.style.display = "flex";

        recipes.forEach(recipe => {
            const card = document.createElement("div");
            card.classList.add("col-md-6", "mb-4");
            card.innerHTML = `
            <div class="card shadow-sm">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center mb-2">
                        <div>
                            <h5 class="card-title mb-0">${recipe.name}</h5>
                            <p class="text-muted mb-0">${recipe.tagLine || ""}</p>
                        </div>
                        <div>
                            <button class="btn btn-warning btn-sm edit-btn" data-id="${recipe.recipeId}">Edit</button>
                            <button class="btn btn-danger btn-sm delete-btn" data-id="${recipe.recipeId}">Delete</button>
                        </div>
                    </div>
                    <p>${recipe.summary}</p>
                    <p><strong>Ingredients:</strong> ${recipe.ingredients.join(", ")}</p>
                    <p><strong>Instructions:</strong><br>${recipe.instructions.map(line => `<div>${line}</div>`).join("")}</p>
                    ${recipe.servingSuggestions ? `<p><strong>Serving Suggestions:</strong> ${recipe.servingSuggestions}</p>` : ""}
                </div>
                <div class="card-footer"><b>Categories:</b> ${(recipe.categories || []).join(" | ")}</div>
            </div>`;
            container.appendChild(card);
        });

        document.querySelectorAll(".edit-btn").forEach(btn =>
            btn.addEventListener("click", () => editRecipe(btn.getAttribute("data-id")))
        );
        document.querySelectorAll(".delete-btn").forEach(btn =>
            btn.addEventListener("click", () => window.deleteRecipe(btn.getAttribute("data-id")))
        );
    }

    // Search
    document.getElementById("searchForm").addEventListener("submit", function (event) {
        event.preventDefault();
        const input = document.getElementById("searchInput").value.trim();
        if (!input) return fetchRecipes();

        fetch(`${BASE_URL}/Search`, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ keyword: input, categories: [] })
        })
            .then(res => res.json())
            .then(data => {
                document.getElementById("allRecipes").style.display = "none";
                displaySearchResults(data);
            })
            .catch(err => console.error("Search error:", err));
    });

    function displaySearchResults(recipes) {
        const results = document.getElementById("searchResults");
        results.innerHTML = "";
        if (!recipes.length) {
            results.innerHTML = `<div class="col-12 text-center"><em>No matching recipes found.</em></div>`;
            return;
        }

        recipes.forEach(recipe => {
            const card = document.createElement("div");
            card.classList.add("col-md-6", "mb-4");
            card.innerHTML = `
            <div class="card shadow-sm">
                <div class="card-body">
                    <h5 class="card-title">${recipe.name}</h5>
                    <p><strong>Ingredients:</strong> ${recipe.ingredients.join(", ")}</p>
                    <p><strong>Instructions:</strong><br>${(recipe.instructions || []).map(l => `<div>${l}</div>`).join("")}</p>
                    ${recipe.servingSuggestions ? `<p><strong>Serving Suggestions:</strong> ${recipe.servingSuggestions}</p>` : ""}
                </div>
            </div>`;
            results.appendChild(card);
        });
    }

    window.deleteRecipe = function (recipeId) {
        if (!confirm("Are you sure you want to delete this recipe?")) return;

        fetch(`${BASE_URL}/${recipeId}`, { method: "DELETE" })
            .then(res => res.status === 204 ? fetchRecipes() : res.text().then(t => { throw new Error(t); }))
            .catch(err => alert("Delete failed: " + err.message));
    };

    // Edit
    window.editRecipe = function (id) {
        fetch(`${BASE_URL}/${id}`)
            .then(res => res.json())
            .then(recipe => {
                document.getElementById("editRecipeId").value = recipe.recipeId;
                document.getElementById("editRecipeName").value = recipe.name;
                document.getElementById("editTagLine").value = recipe.tagLine || "";
                document.getElementById("editSummary").value = recipe.summary || "";
                document.getElementById("editIngredients").value = recipe.ingredients.join(", ");
                document.getElementById("editInstructions").value = recipe.instructions.join("\n");
                document.getElementById("editServingSuggestions").value = recipe.servingSuggestions || "";

                selectedEditCategories = (recipe.categories || []).map(cat =>
                    parseInt(Object.keys(categoryMapping).find(key => categoryMapping[key] === cat))
                );
                document.getElementById("editCategories").value = JSON.stringify(selectedEditCategories);
                document.getElementById("editCategoryDropdown").innerText = selectedEditCategories.map(id => categoryMapping[id]).join(", ") || "Select Categories";

                new bootstrap.Modal(document.getElementById("editRecipeModal")).show();
            });
    };

    document.getElementById("updateRecipe").addEventListener("click", function (event) {
        event.preventDefault();

        const name = document.getElementById("editRecipeName").value.trim();
        if (!name) return alert("❗ Invalid data: Recipe name is required.");

        const updated = {
            recipeId: document.getElementById("editRecipeId").value,
            name,
            tagLine: document.getElementById("editTagLine").value.trim(),
            summary: document.getElementById("editSummary").value.trim(),
            ingredients: document.getElementById("editIngredients").value.split(",").map(i => i.trim()),
            instructions: document.getElementById("editInstructions").value.split("\n").map(i => i.trim()),
            categories: JSON.parse(document.getElementById("editCategories").value || "[]"),
            servingSuggestions: document.getElementById("editServingSuggestions").value.trim()
        };

        fetch(`${BASE_URL}/${updated.recipeId}`, {
            method: "PUT",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(updated)
        })
            .then(res => {
                if (!res.ok) throw new Error(`Server error: ${res.status}`);
                return res.text();
            })
            .then(() => {
                alert("✅ Recipe updated!");
                bootstrap.Modal.getInstance(document.getElementById("editRecipeModal")).hide();
                fetchRecipes();
            })
            .catch(err => {
                console.error("Update error:", err);
                alert("❌ Failed to update recipe.");
            });
    });

    // Save
    document.getElementById("saveRecipe").addEventListener("click", function (event) {
        event.preventDefault();

        const name = document.getElementById("recipeName").value.trim();
        if (!name) return alert("❗ Invalid data: Recipe name is required.");

        const recipe = {
            name,
            tagLine: document.getElementById("tagLine").value.trim(),
            summary: document.getElementById("summary").value.trim(),
            ingredients: document.getElementById("ingredients").value.split(",").map(i => i.trim()),
            instructions: document.getElementById("instructions").value.split("\n").map(i => i.trim()),
            categories: selectedCategories.map(id => categoryMapping[id]),
            servingSuggestions: document.getElementById("servingSuggestions").value.trim()
        };

        fetch(`${BASE_URL}/Add`, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(recipe)
        })
            .then(res => res.json())
            .then(data => {
                if (data.success) {
                    alert("✅ Recipe added!");
                    bootstrap.Modal.getInstance(document.getElementById("addRecipeModal")).hide();
                    fetchRecipes();
                } else {
                    alert(data.message || "Failed to add recipe.");
                }
            })
            .catch(err => {
                console.error("Add error:", err);
                alert("❌ Error adding recipe.");
            });
    });

    document.querySelectorAll("#categoryList .dropdown-item").forEach(item => {
        item.addEventListener("click", function (e) {
            e.preventDefault();
            const value = parseInt(this.getAttribute("data-value"));
            if (selectedCategories.includes(value)) {
                selectedCategories = selectedCategories.filter(v => v !== value);
                this.classList.remove("active");
            } else {
                selectedCategories.push(value);
                this.classList.add("active");
            }
            document.getElementById("categories").value = JSON.stringify(selectedCategories);
            document.getElementById("categoryDropdown").innerText = selectedCategories.map(id => categoryMapping[id]).join(", ") || "Select Categories";
        });
    });
});
