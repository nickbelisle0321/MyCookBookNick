﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.Json.Serialization;
using System.Text.Json;
using System.Threading.Tasks;
using FluentAssertions;
using MyCookBookAPI.Models;

namespace MyCookBook.API.Tests
{
    public class RecipeModelTests
    {
        [Fact(DisplayName = "CM01 - Recipe Model Defaults")]
        public void Recipe_Constructor_InitializesEmptyLists()
        {
            var recipe = new Recipe();

            recipe.Ingredients.Should().NotBeNull();
            recipe.Ingredients.Should().BeEmpty();

            recipe.Instructions.Should().NotBeNull();
            recipe.Instructions.Should().BeEmpty();
        }

        [Fact(DisplayName = "CM02 - Enum Conversion to String")]
        public void CategoryType_Enum_SerializesToString()
        {
            var recipe = new Recipe
            {
                RecipeId = "test-id",
                Name = "Test",
                Categories = new List<CategoryType> { CategoryType.Vegan }
            };

            var json = JsonSerializer.Serialize(recipe, new JsonSerializerOptions
            {
                Converters = { new JsonStringEnumConverter() }
            });

            json.Should().Contain("\"Vegan\"");
        }

        [Fact(DisplayName = "CM03 - Recipe Model Null Handling")]
        public void Recipe_HandlesNullsSafely()
        {
            var recipe = new Recipe();

            recipe.Name.Should().BeNull();
            recipe.Summary.Should().BeNull();
            recipe.Ingredients.Should().NotBeNull();
            recipe.Instructions.Should().NotBeNull();
        }

        [Fact(DisplayName = "CM04 - Invalid Enum Serialization Throws Error")]
        public void Deserialize_InvalidEnum_ThrowsJsonException()
        {
            // Arrange
            string invalidJson = @"{
        ""name"": ""Test Recipe"",
        ""ingredients"": [""Eggs"", ""Milk""],
        ""instructions"": [""Mix"", ""Cook""],
        ""categories"": [""NotAValidEnum""]
    }";

            // Act & Assert
            var exception = Record.Exception(() =>
            {
                JsonSerializer.Deserialize<Recipe>(invalidJson, new JsonSerializerOptions
                {
                    Converters = { new JsonStringEnumConverter() },
                    PropertyNameCaseInsensitive = true
                });
            });

            Assert.NotNull(exception); // Ensure something threw
            Assert.IsType<JsonException>(exception); // Ensure it's the expected type
        }

        [Theory(DisplayName = "CM05 - Ingredient Parsing Handles Empty/Whitespace")]
        [InlineData("Salt, , Pepper, ", new[] { "Salt", "Pepper" })]
        [InlineData("Tomato", new[] { "Tomato" })]
        [InlineData(" , , ", new string[] { })]
        public void Ingredients_ParsedCorrectly(string rawInput, string[] expected)
        {
            var ingredients = rawInput
                .Split(",", StringSplitOptions.RemoveEmptyEntries)
                .Select(i => i.Trim())
                .Where(i => !string.IsNullOrWhiteSpace(i))
                .ToList();

            ingredients.Should().BeEquivalentTo(expected);
        }

        [Theory(DisplayName = "CM06 - Instruction Step Parsing Handles Newlines")]
        [InlineData("Step one\nStep two\nStep three", new[] { "Step one", "Step two", "Step three" })]
        [InlineData("Mix\nBake", new[] { "Mix", "Bake" })]
        [InlineData("\n\nStep A\n\n", new[] { "Step A" })]
        public void Instructions_ParsedFromMultilineString(string input, string[] expected)
        {
            var parsedInstructions = input
                .Split("\n", StringSplitOptions.RemoveEmptyEntries)
                .Select(s => s.Trim())
                .Where(s => !string.IsNullOrWhiteSpace(s))
                .ToList();

            parsedInstructions.Should().BeEquivalentTo(expected);
        }
    }
}
