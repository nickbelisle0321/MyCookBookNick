﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using FluentAssertions;
using Moq;
using MyCookBookAPI.Models;
using MyCookBookAPI.Repositories;
using MyCookBookAPI.Services;

namespace MyCookBook.API.Tests
{
    public class RecipeServiceIntegrationTests
    {
        private readonly Mock<IRecipeRepository> _mockRepo;
        private readonly RecipeService _service;

        public RecipeServiceIntegrationTests()
        {
            _mockRepo = new Mock<IRecipeRepository>();
            _service = new RecipeService(_mockRepo.Object);
        }

        [Fact(DisplayName = "CI01 - Service Calls Repository Correctly")]
        public void AddRecipe_CallsRepositoryOnce()
        {
            // Arrange
            var recipe = new Recipe { RecipeId = "1", Name = "Pizza" };

            // Act
            _service.AddRecipe(recipe);

            // Assert
            _mockRepo.Verify(r => r.AddRecipe(recipe), Times.Once);
        }

        [Fact(DisplayName = "CI02 - Search Filters by Keyword & Category")]
        public void SearchRecipes_FiltersByKeywordAndCategory()
        {
            // Arrange
            var testData = new List<Recipe>
            {
                new Recipe { Name = "Chocolate Cake", Categories = new List<CategoryType> { CategoryType.Dessert } },
                new Recipe { Name = "Apple Pie", Categories = new List<CategoryType> { CategoryType.Dessert } },
                new Recipe { Name = "Chicken Soup", Categories = new List<CategoryType> { CategoryType.Dinner } }
            };

            _mockRepo.Setup(r => r.SearchRecipes(It.IsAny<RecipeSearchRequest>()))
                     .Returns<RecipeSearchRequest>(req => testData
                         .Where(r => r.Name.Contains(req.Keyword, System.StringComparison.OrdinalIgnoreCase)
                                 && r.Categories.Contains(req.Categories.FirstOrDefault()))
                         .ToList());

            var request = new RecipeSearchRequest { Keyword = "Cake", Categories = new List<CategoryType> { CategoryType.Dessert } };

            // Act
            var results = _service.SearchRecipes(request);

            // Assert
            Assert.Single(results);
            Assert.Equal("Chocolate Cake", results.First().Name);
        }

        [Fact(DisplayName = "CI03 - Add and Fetch Recipe Integration")]
        public void AddAndFetchRecipe_ReturnsCorrectRecipe()
        {
            // Arrange
            var recipe = new Recipe { RecipeId = "123", Name = "Toast" };
            _mockRepo.Setup(r => r.GetRecipeById("123")).Returns(recipe);

            // Act
            _service.AddRecipe(recipe);
            var fetched = _service.GetRecipeById("123");

            // Assert
            Assert.Equal("Toast", fetched.Name);
            _mockRepo.Verify(r => r.AddRecipe(recipe), Times.Once);
            _mockRepo.Verify(r => r.GetRecipeById("123"), Times.Once);
        }

        [Fact(DisplayName = "CI04 - Search Case Insensitive Match")]
        public void SearchRecipe_HandlesCaseInsensitiveMatch()
        {
            // Arrange
            var testData = new List<Recipe>
            {
                new Recipe { Name = "Pancake" },
                new Recipe { Name = "PANCAKE" },
                new Recipe { Name = "pAnCaKe" },
                new Recipe { Name = "Waffle" }
            };

            _mockRepo.Setup(r => r.SearchRecipes(It.IsAny<RecipeSearchRequest>()))
                     .Returns<RecipeSearchRequest>(req => testData
                         .Where(r => r.Name.Contains(req.Keyword, System.StringComparison.OrdinalIgnoreCase))
                         .ToList());

            var request = new RecipeSearchRequest { Keyword = "PANCAKE" };

            // Act
            var results = _service.SearchRecipes(request);

            // Assert
            Assert.Equal(3, results.Count);
            Assert.All(results, r => Assert.Contains("pancake", r.Name.ToLower()));
        }
        [Theory(DisplayName = "CI05 - Category Filter Returns Only Matching Recipes")]
        [InlineData(CategoryType.Dessert)]
        [InlineData(CategoryType.Breakfast)]
        public void Filter_ByCategory_ReturnsCorrect(CategoryType category)
        {
            var recipes = new List<Recipe>
    {
        new() { Name = "Cake", Categories = new List<CategoryType> { CategoryType.Dessert } },
        new() { Name = "Pancakes", Categories = new List<CategoryType> { CategoryType.Breakfast } },
        new() { Name = "Salad", Categories = new List<CategoryType> { CategoryType.Vegan } }
    };

            var mockRepo = new Mock<IRecipeRepository>();
            mockRepo.Setup(r => r.SearchRecipes(It.IsAny<RecipeSearchRequest>()))
                .Returns<RecipeSearchRequest>(req =>
                    recipes.Where(r => r.Categories.Contains(req.Categories.FirstOrDefault())).ToList());

            var service = new RecipeService(mockRepo.Object);
            var result = service.SearchRecipes(new RecipeSearchRequest
            {
                Keyword = "",
                Categories = new List<CategoryType> { category }
            });

            result.Should().OnlyContain(r => r.Categories.Contains(category));
        }
    }
}
