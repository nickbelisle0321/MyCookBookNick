﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http.Json;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using FluentAssertions;
using Microsoft.AspNetCore.Mvc.Testing;
using MyCookBookAPI.Models;
using Xunit.Abstractions;
using System.Text.Json.Serialization;
using System.Text.Json;

namespace MyCookBook.API.Tests
{
    public class SystemIntegrationTests : IClassFixture<WebApplicationFactory<Program>>
    {
        private readonly HttpClient _client;
        private readonly ITestOutputHelper _output;

        public SystemIntegrationTests(WebApplicationFactory<Program> factory, ITestOutputHelper output)
        {
            _client = factory.CreateClient();
            _output = output;
        }

        [Fact(DisplayName = "SIT02 - Get All Recipes Returns List")]
        public async Task GetAllRecipes_ReturnsList()
        {
            // Act
            var response = await _client.GetAsync("/api/recipe/GetAll");

            _output.WriteLine($"GET /api/recipe/GetAll Status Code: {response.StatusCode}");

            response.StatusCode.Should().Be(HttpStatusCode.OK);

            var options = new JsonSerializerOptions
            {
                Converters = { new JsonStringEnumConverter() }
            };

            var recipes = await response.Content.ReadFromJsonAsync<List<Recipe>>(options);

            _output.WriteLine($"Recipes Count Returned: {recipes?.Count ?? 0}");
            recipes.Should().NotBeNull();
            recipes.Should().NotBeEmpty();
        }

        [Fact(DisplayName = "SIT03 - Delete Recipe End-to-End")]
        public async Task DeleteRecipe_EndToEnd_DeletesSuccessfully()
        {
            // Step 1: Create a new recipe
            var newRecipe = new Recipe
            {
                Name = "Test Delete",
                TagLine = "To be deleted",
                Summary = "Delete test summary",
                Instructions = new List<string> { "Test" },
                Ingredients = new List<string> { "Test" },
                Categories = new List<CategoryType> { CategoryType.Snack }
            };

            var postResponse = await _client.PostAsJsonAsync("/api/recipe/Add", newRecipe);
            _output.WriteLine($"POST Status Code: {postResponse.StatusCode}");
            var postBody = await postResponse.Content.ReadAsStringAsync();
            _output.WriteLine($"POST Body: {postBody}");

            postResponse.StatusCode.Should().Be(HttpStatusCode.OK);

            // Deserialize the POST response
            var options = new JsonSerializerOptions
            {
                PropertyNameCaseInsensitive = true,
                Converters = { new JsonStringEnumConverter() }
            };

            AddRecipeResponse? responseData = JsonSerializer.Deserialize<AddRecipeResponse>(postBody, options);
            string recipeId = responseData?.Recipe?.RecipeId ?? throw new Exception("❌ RecipeId was null!");
            _output.WriteLine($"Extracted RecipeId: {recipeId}");

            // Step 2: Confirm the recipe exists (retry if necessary)
            bool found = false;
            for (int i = 0; i < 5; i++)
            {
                var getResponse = await _client.GetAsync($"/api/recipe/{recipeId}");
                _output.WriteLine($"Retry attempt {i + 1} - GET /api/recipe/{recipeId} = {getResponse.StatusCode}");
                if (getResponse.StatusCode == HttpStatusCode.OK)
                {
                    found = true;
                    break;
                }
                await Task.Delay(500);
            }

            if (!found)
            {
                throw new Exception("Recipe was not found after creation.");
            }

            // Step 3: Delete the recipe
            var deleteResponse = await _client.DeleteAsync($"/api/recipe/{recipeId}");
            _output.WriteLine($"DELETE Status Code: {deleteResponse.StatusCode}");

            deleteResponse.StatusCode.Should().Be(HttpStatusCode.NoContent);

            // Step 4: Ensure recipe is gone
            var checkResponse = await _client.GetAsync($"/api/recipe/{recipeId}");
            _output.WriteLine($"Final GET Status Code: {checkResponse.StatusCode}");

            checkResponse.StatusCode.Should().Be(HttpStatusCode.NotFound);
        }
        public class AddRecipeResponse
        {
            public bool Success { get; set; }
            public string Message { get; set; } = string.Empty;

            // The casing MUST match the JSON property or use [JsonPropertyName]
            public Recipe Recipe { get; set; } = new();
        }

        [Fact(DisplayName = "SIT04 - Add, Update, and Retrieve Recipe")]
        public async Task AddUpdateRetrieveRecipe_WorksCorrectly()
        {
            var options = new JsonSerializerOptions
            {
                PropertyNameCaseInsensitive = true,
                Converters = { new JsonStringEnumConverter() }
            };

            // Step 1: Add recipe
            var recipe = new Recipe
            {
                Name = "Salad",
                TagLine = "Test",
                Summary = "Fresh",
                Instructions = new List<string> { "Mix" },
                Ingredients = new List<string> { "Lettuce" },
                Categories = new List<CategoryType> { CategoryType.Vegan }
            };

            var postResponse = await _client.PostAsJsonAsync("/api/recipe/Add", recipe);
            _output.WriteLine($"POST Status Code: {postResponse.StatusCode}");
            var postBody = await postResponse.Content.ReadAsStringAsync();
            _output.WriteLine($"POST Body: {postBody}");
            postResponse.StatusCode.Should().Be(HttpStatusCode.OK);

            var result = JsonSerializer.Deserialize<AddRecipeResponse>(postBody, options);
            var recipeId = result?.Recipe?.RecipeId ?? throw new Exception("❌ RecipeId was null");

            // Step 2: Update the recipe
            result!.Recipe.Name = "Greek Salad";
            var updateResponse = await _client.PutAsJsonAsync($"/api/recipe/{recipeId}", result.Recipe);
            _output.WriteLine($"PUT Status Code: {updateResponse.StatusCode}");
            updateResponse.StatusCode.Should().Be(HttpStatusCode.NoContent);

            // Step 3: GET updated recipe
            var getResponse = await _client.GetAsync($"/api/recipe/{recipeId}");
            _output.WriteLine($"GET Status Code: {getResponse.StatusCode}");
            getResponse.EnsureSuccessStatusCode();

            var updated = await getResponse.Content.ReadFromJsonAsync<Recipe>(options);
            updated!.Name.Should().Be("Greek Salad");
        }

        [Fact(DisplayName = "SIT05 - Multiple Deletes")]
        public async Task DeleteRecipe_Twice_SecondFails()
        {
            var options = new JsonSerializerOptions
            {
                PropertyNameCaseInsensitive = true,
                Converters = { new JsonStringEnumConverter() }
            };

            // Step 1: Add a temporary recipe
            var recipe = new Recipe
            {
                Name = "Temp",
                TagLine = "Twice",
                Summary = "To delete",
                Instructions = new List<string> { "Y" },
                Ingredients = new List<string> { "X" },
                Categories = new List<CategoryType> { CategoryType.Dinner }
            };

            var postResponse = await _client.PostAsJsonAsync("/api/recipe/Add", recipe);
            _output.WriteLine($"POST Status Code: {postResponse.StatusCode}");
            var postBody = await postResponse.Content.ReadAsStringAsync();
            _output.WriteLine($"POST Body: {postBody}");
            postResponse.StatusCode.Should().Be(HttpStatusCode.OK);

            var result = JsonSerializer.Deserialize<AddRecipeResponse>(postBody, options);
            string recipeId = result?.Recipe?.RecipeId ?? throw new Exception("❌ RecipeId was null");

            // Step 2: First DELETE
            var deleteResponse1 = await _client.DeleteAsync($"/api/recipe/{recipeId}");
            _output.WriteLine($"DELETE 1 Status Code: {deleteResponse1.StatusCode}");
            deleteResponse1.StatusCode.Should().Be(HttpStatusCode.NoContent);

            // Step 3: Second DELETE should return 404
            var deleteResponse2 = await _client.DeleteAsync($"/api/recipe/{recipeId}");
            _output.WriteLine($"DELETE 2 Status Code: {deleteResponse2.StatusCode}");
            deleteResponse2.StatusCode.Should().Be(HttpStatusCode.NotFound);
        }
    }

    public class RecipeResponse
    {
        public bool Success { get; set; }
        public string Message { get; set; } = string.Empty;
        public Recipe Recipe { get; set; } = new Recipe();
    }
}
