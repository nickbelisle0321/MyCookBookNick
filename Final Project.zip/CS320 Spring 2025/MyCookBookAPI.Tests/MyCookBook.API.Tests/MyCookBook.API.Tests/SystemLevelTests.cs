﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http.Json;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using FluentAssertions;
using Microsoft.AspNetCore.Mvc.Testing;
using MyCookBookAPI.Models;
using System.Text.Json;
using Xunit.Abstractions;

namespace MyCookBook.API.Tests
{
    public class SystemLevelTests : IClassFixture<WebApplicationFactory<Program>>
    {
        private readonly HttpClient _client;
        private readonly ITestOutputHelper _output;

        public SystemLevelTests(WebApplicationFactory<Program> factory, ITestOutputHelper output)
        {
            _client = factory.CreateClient();
            _output = output;
        }

        [Fact(DisplayName = "ST01 - Delete Recipe and Verify Deletion")]
        public async Task DeleteRecipe_RemovesRecipe_AndReturnsNotFound()
        {
            var newRecipe = new Recipe
            {
                Name = "Temp Recipe",
                Summary = "Temporary test recipe",
                TagLine = "Just a test",
                Ingredients = new List<string> { "Flour", "Water" },
                Instructions = new List<string> { "Mix", "Bake" },
                Categories = new List<CategoryType> { CategoryType.Dessert }
            };

            var postResponse = await _client.PostAsJsonAsync("/api/recipe/Add", newRecipe);
            _output.WriteLine("POST Status Code: " + postResponse.StatusCode);
            var responseContent = await postResponse.Content.ReadAsStringAsync();
            _output.WriteLine("POST Body: " + responseContent);

            postResponse.StatusCode.Should().Be(System.Net.HttpStatusCode.OK);

            var result = System.Text.Json.JsonSerializer.Deserialize<JsonElement>(responseContent);
            var recipeId = result.GetProperty("recipe").GetProperty("recipeId").GetString();
            _output.WriteLine("Created Recipe ID: " + recipeId);

            var deleteResponse = await _client.DeleteAsync($"/api/recipe/{recipeId}");
            _output.WriteLine("DELETE Status Code: " + deleteResponse.StatusCode);
            deleteResponse.StatusCode.Should().Be(System.Net.HttpStatusCode.NoContent);

            var getResponse = await _client.GetAsync($"/api/recipe/{recipeId}");
            _output.WriteLine("GET Status Code After Delete: " + getResponse.StatusCode);
            getResponse.StatusCode.Should().Be(System.Net.HttpStatusCode.NotFound);
        }

        [Fact(DisplayName = "ST02 - Add Recipe with Multiple Categories")]
        public async Task AddRecipe_WithMultipleCategories_ReturnsCorrectRecipe()
        {
            var newRecipe = new Recipe
            {
                Name = "Salad",
                Summary = "A healthy green salad.",
                TagLine = "Fresh and tasty",
                Ingredients = new List<string> { "Lettuce", "Tomatoes" },
                Instructions = new List<string> { "Chop", "Toss", "Serve" },
                Categories = new List<CategoryType> { CategoryType.Vegan, CategoryType.GlutenFree }
            };

            var postResponse = await _client.PostAsJsonAsync("/api/recipe/Add", newRecipe);
            _output.WriteLine("POST Status Code: " + postResponse.StatusCode);
            var responseContent = await postResponse.Content.ReadAsStringAsync();
            _output.WriteLine("POST Body: " + responseContent);

            postResponse.EnsureSuccessStatusCode();

            var result = System.Text.Json.JsonSerializer.Deserialize<JsonElement>(responseContent);
            var recipeJson = result.GetProperty("recipe");
            var categories = recipeJson.GetProperty("categories").EnumerateArray().Select(c => c.GetString()).ToList();

            categories.Should().Contain(new[] { "Vegan", "GlutenFree" });
        }

        [Fact(DisplayName = "ST03 - Create Recipe with Empty Instructions")]
        public async Task CreateRecipe_WithEmptyInstructions_HandledCorrectly()
        {
            var newRecipe = new Recipe
            {
                Name = "No Instruction Dish",
                Summary = "Recipe without instructions.",
                TagLine = "Mystery meal",
                Ingredients = new List<string> { "Water", "Salt" },
                Instructions = new List<string>(), // ✅ empty list, which is the actual test
                Categories = new List<CategoryType> { CategoryType.Dinner }
            };

            var postResponse = await _client.PostAsJsonAsync("/api/recipe/Add", newRecipe);
            _output.WriteLine("POST Status Code: " + postResponse.StatusCode);
            var responseContent = await postResponse.Content.ReadAsStringAsync();
            _output.WriteLine("POST Body: " + responseContent);

            postResponse.StatusCode.Should().Be(System.Net.HttpStatusCode.OK);

            var result = System.Text.Json.JsonSerializer.Deserialize<JsonElement>(responseContent);
            var recipe = result.GetProperty("recipe");
            recipe.GetProperty("instructions").GetArrayLength().Should().Be(0);
        }
        [Fact(DisplayName = "ST04 - Create Recipe With Missing Fields")]
        public async Task CreateRecipe_WithMissingFields_ReturnsBadRequest()
        {
            var incompleteRecipe = new
            {
                Name = "", // Required fields missing or invalid
                Ingredients = new List<string> { "Water" }
            };

            var postResponse = await _client.PostAsJsonAsync("/api/recipe/Add", incompleteRecipe);
            var postBody = await postResponse.Content.ReadAsStringAsync();

            _output.WriteLine($"POST Status Code: {postResponse.StatusCode}");
            _output.WriteLine($"POST Body: {postBody}");

            postResponse.StatusCode.Should().Be(HttpStatusCode.BadRequest);
            postBody.Should().Contain("Summary").And.Contain("TagLine");
        }
        [Theory(DisplayName = "ST05 - Create Recipes with Various Valid Names")]
        [InlineData("Smoothie")]
        [InlineData("Tuna Salad")]
        [InlineData("  Pudding  ")]
        public async Task CreateRecipe_WithDifferentNames_Succeeds(string recipeName)
        {
            var recipe = new Recipe
            {
                Name = recipeName.Trim(),
                TagLine = "Quick meal",
                Summary = "Great option",
                Instructions = new List<string> { "Step 1" },
                Ingredients = new List<string> { "Item 1" },
                Categories = new List<CategoryType> { CategoryType.Breakfast }
            };

            var response = await _client.PostAsJsonAsync("/api/recipe/add", recipe);
            response.StatusCode.Should().Be(HttpStatusCode.OK);
        }
        [Theory(DisplayName = "ST06 - Invalid Category Type Fails Deserialization")]
        [InlineData("[\"UnknownCategory\"]")]
        [InlineData("[123]")]
        public async Task CreateRecipe_WithInvalidCategory_Fails(string invalidCategoryJson)
        {
            var json = $@"{{
        ""name"": ""Bad Recipe"",
        ""tagLine"": ""Fails"",
        ""summary"": ""Invalid enum"",
        ""instructions"": [""Do something""],
        ""ingredients"": [""Thing""],
        ""categories"": {invalidCategoryJson}
    }}";

            var content = new StringContent(json, Encoding.UTF8, "application/json");
            var response = await _client.PostAsync("/api/recipe/add", content);

            response.StatusCode.Should().Be(HttpStatusCode.BadRequest);
        }
    }
}
