﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using MyCookBookAPI.Models;
using MyCookBookAPI.Services;
using System;
using System.Collections.Generic;
using System.Linq;

namespace MyCookBookApi.Controllers
{
    [ApiController]
    [Route("api/Recipe")]
    public class RecipeController : ControllerBase
    {
        private readonly IRecipeService _recipeService;
        private readonly ILogger<RecipeController> _logger;

        public RecipeController(IRecipeService recipeService, ILogger<RecipeController> logger)
        {
            _recipeService = recipeService;
            _logger = logger;
        }

        [HttpGet("GetAll")]
        public ActionResult<IEnumerable<Recipe>> GetAllRecipes()
        {
            try
            {
                var recipes = _recipeService.GetAllRecipes();
                return Ok(recipes);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error occurred while retrieving all recipes.");
                return StatusCode(500, "An error occurred while processing your request.");
            }
        }

        [HttpGet("{id}")]
        public ActionResult<Recipe> GetRecipeById(string id)
        {
            try
            {
                var recipe = _recipeService.GetRecipeById(id);
                if (recipe == null)
                    return NotFound($"Recipe with ID '{id}' not found.");

                return Ok(recipe);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"Error fetching recipe with ID {id}");
                return StatusCode(500, "An internal error occurred.");
            }
        }

        [HttpPost("search")]
        public ActionResult<IEnumerable<Recipe>> SearchRecipes([FromBody] RecipeSearchRequest searchRequest)
        {
            try
            {
                if (searchRequest == null || string.IsNullOrWhiteSpace(searchRequest.Keyword))
                    return BadRequest("Invalid search request.");

                searchRequest.Categories ??= new List<CategoryType>();

                var recipes = _recipeService.SearchRecipes(searchRequest);
                return Ok(recipes);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error during recipe search.");
                return StatusCode(500, "An internal server error occurred.");
            }
        }

        [HttpPut("{id}")]
        public IActionResult UpdateRecipe(string id, [FromBody] Recipe recipe)
        {
            try
            {
                if (recipe == null || string.IsNullOrWhiteSpace(recipe.Name))
                    return BadRequest("Invalid recipe data.");

                var updated = _recipeService.UpdateRecipe(id, recipe);
                if (!updated)
                    return NotFound($"No recipe found with ID {id}.");

                return NoContent();
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"Error updating recipe with ID {id}");
                return StatusCode(500, "An internal error occurred.");
            }
        }

        [HttpPost("Add")]
        public ActionResult CreateRecipe([FromBody] Recipe recipe)
        {
            try
            {
                if (recipe == null || string.IsNullOrWhiteSpace(recipe.Name))
                    return BadRequest(new { success = false, message = "Invalid recipe data." });

                if (recipe.Categories.Any(c => !Enum.IsDefined(typeof(CategoryType), c)))
                    return BadRequest(new { success = false, message = "Invalid category value detected." });

                recipe.RecipeId = Guid.NewGuid().ToString();
                _recipeService.AddRecipe(recipe);

                return Ok(new
                {
                    success = true,
                    message = "Recipe added successfully",
                    recipe
                });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error adding recipe.");
                return StatusCode(500, new { success = false, message = "An internal error occurred." });
            }
        }

        [HttpDelete("{id}")]
        public IActionResult DeleteRecipe(string id)
        {
            try
            {
                var deleted = _recipeService.DeleteRecipe(id);
                if (!deleted)
                    return NotFound($"No recipe found with ID {id}.");

                return NoContent();
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"Error deleting recipe with ID {id}");
                return StatusCode(500, "An internal server error occurred.");
            }
        }
    }
}
