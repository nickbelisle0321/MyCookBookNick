﻿using Google.Cloud.Firestore;
using System.Collections.Generic;
using System.Text.Json.Serialization;

namespace MyCookBookAPI.Models
{

    [FirestoreData]
    public class Recipe
    {
        [FirestoreProperty] public string? RecipeId { get; set; } // Auto-generated unique ID
        [FirestoreProperty] public string Name { get; set; }
        [FirestoreProperty] public string TagLine { get; set; }
        [FirestoreProperty] public string Summary { get; set; }
        [FirestoreProperty] public string? ServingSuggestions { get; set; } // Optional field
        [FirestoreProperty] public List<string> Instructions { get; set; } = new List<string>();
        [FirestoreProperty]  public List<string> Ingredients { get; set; } = new List<string>();

        [FirestoreProperty(ConverterType = typeof(CategoryTypeConverter))]
        [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
        public List<CategoryType>? Categories { get; set; } = new List<CategoryType>();

        public Recipe() { }
    }
}
