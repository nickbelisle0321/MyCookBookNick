﻿// recipe.js

document.addEventListener("DOMContentLoaded", function () {
    const BASE_URL = "https://localhost:7182/api/Recipe";
    let selectedCategories = [];

    const categoryMapping = {
        0: "Breakfast",
        1: "Lunch",
        2: "Dinner",
        3: "Dessert",
        4: "Snack",
        5: "Vegan",
        6: "Vegetarian",
        7: "GlutenFree",
        8: "Keto",
        9: "LowCarb",
        10: "HighProtein"
    };

    console.log("Page loaded, fetching recipes...");
    fetchRecipes();

    /** ========== 🛠 Fixing "Save Recipe" Button ========== */
    setTimeout(() => {
        const saveRecipeBtn = document.getElementById("saveRecipe");
        if (saveRecipeBtn) {
            saveRecipeBtn.addEventListener("click", function (event) {
                event.preventDefault();
                console.log("Save Recipe button clicked!");

                const recipe = {
                    name: document.getElementById("recipeName").value.trim(),
                    tagLine: document.getElementById("tagLine").value.trim(),
                    summary: document.getElementById("summary").value.trim(),
                    ingredients: document.getElementById("ingredients").value.split(",").map(i => i.trim()),
                    instructions: document.getElementById("instructions").value.split("\n").map(i => i.trim()),
                    categories: selectedCategories.map(id => categoryMapping[id]) // Send as strings
                };

                console.log("Recipe to be sent:", recipe);

                fetch(`${BASE_URL}/Add`, {
                    method: "POST",
                    headers: { "Content-Type": "application/json" },
                    body: JSON.stringify(recipe)
                })
                    .then(response => response.json())
                    .then(data => {
                        console.log("Server response:", data);
                        if (data.success) {
                            alert("Recipe added!");
                            fetchRecipes();
                        } else {
                            alert(data.message || "Failed to add recipe.");
                        }
                    })
                    .catch(error => {
                        console.error("Error adding recipe:", error);
                        alert("Failed to add recipe. " + error.message);
                    });
            });
        } else {
            console.error("Element #saveRecipe not found!");
        }
    }, 500); // 🛠 Delaying to ensure the DOM loads first

    /** ========== 🛠 Fixing "Add Recipe" Button ========== */
    const addRecipeBtn = document.getElementById("addRecipeBtn");
    if (addRecipeBtn) {
        addRecipeBtn.addEventListener("click", function () {
            console.log("Add Recipe button clicked!");
            document.getElementById("addRecipeForm").reset();
            document.getElementById("categoryDropdown").innerText = "Select Categories";
            document.getElementById("categories").value = "[]";
            selectedCategories = [];

            let modalElement = document.getElementById('addRecipeModal');
            if (modalElement) {
                let modal = new bootstrap.Modal(modalElement);
                modal.show();
            } else {
                console.error("Modal #addRecipeModal not found!");
            }
        });
    } else {
        console.error("Element #addRecipeBtn not found!");
    }

    /** ========== 🛠 Fixing "Search Bar" Not Found Issue ========== */
    setTimeout(() => {
        const searchForm = document.getElementById("searchForm");
        if (searchForm) {
            searchForm.addEventListener("submit", function (e) {
                e.preventDefault();
                console.log("Search form submitted!");
                searchRecipes();
            });
        } else {
            console.error("Element #searchForm not found!"); // 🛠 Logs error if missing
        }
    }, 500);

    /** ========== Recipe Search Handling ========== */
    const searchInput = document.getElementById("searchInput");
    const searchButton = document.getElementById("searchButton");

    if (searchInput) {
        searchInput.addEventListener("keydown", function (event) {
            if (event.key === "Enter") {
                event.preventDefault();
                console.log("Enter key pressed, executing search...");
                searchRecipes();
            }
        });
    } else {
        console.error("Element #searchInput not found!");
    }

    if (searchButton) {
        searchButton.addEventListener("click", function () {
            console.log("Search button clicked!");
            searchRecipes();
        });
    } else {
        console.error("Element #searchButton not found!");
    }

    /** ========== Fetch All Recipes ========== */
    function fetchRecipes() {
        console.log("Fetching all recipes...");
        fetch(`${BASE_URL}/GetAll`)
            .then(response => response.json())
            .then(data => {
                console.log("Recipes received:", data);
                data.forEach(r => {
                    r.categories = (r.categories || []).map(c => typeof c === "number" ? categoryMapping[c] : c);
                });
                displayRecipes(data);
            })
            .catch(err => console.error("Fetch error:", err));
    }

    /** ========== Display All Recipes ========== */
    function displayRecipes(recipes) {
        const container = document.getElementById("recipeCards");
        container.innerHTML = "";

        recipes.forEach(recipe => {
            const categoriesText = (recipe.categories || []).join(" | ");
            const card = `
                <div class="mb-3">
                    <div class="card shadow-sm">
                        <div class="card-body">
                            <h5 class="card-title">${recipe.name}</h5>
                            <p class="text-muted">${recipe.tagLine || ""}</p>
                            <p>${recipe.summary}</p>
                            <p><strong>Ingredients:</strong> ${recipe.ingredients.join(", ")}</p>
                            <p><strong>Instructions:</strong> ${recipe.instructions.join("<br>")}</p>
                        </div>
                        <div class="card-footer">
                            <b>Categories:</b> ${categoriesText}
                        </div>
                    </div>
                </div>`;
            container.innerHTML += card;
        });
    }

    window.searchRecipes = function () {
        const query = searchInput ? searchInput.value.trim() : "";
        console.log("Search initiated. Query:", query);

        if (!query) {
            console.warn("Search aborted: Query is empty");
            return;
        }

        fetch(`${BASE_URL}/Search`, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ keyword: query, categories: [] })
        })
            .then(response => response.json())
            .then(data => {
                console.log("Search results received:", data);
                updateSearchResults(data);
            })
            .catch(error => console.error("Search error:", error));
    };

    /** ========== Recipe Search Results Update ========== */
    function updateSearchResults(recipes) {
        const container = document.getElementById("recipeCards");

        container.innerHTML = ""; // Clear previous recipes

        if (!recipes || recipes.length === 0) {
            console.log("No recipes found for search query.");
            container.innerHTML = "<p class='text-center'>No matching recipes found.</p>";
            return;
        }

        console.log("Displaying search results...");
        recipes.forEach(recipe => {
            const categoriesText = (recipe.categories || []).join(" | ");
            const card = `
            <div class="mb-3">
                <div class="card shadow-sm">
                    <div class="card-body">
                        <h5 class="card-title">${recipe.name}</h5>
                        <p class="text-muted">${recipe.tagLine || ""}</p>
                        <p>${recipe.summary}</p>
                        <p><strong>Ingredients:</strong> ${recipe.ingredients.join(", ")}</p>
                        <p><strong>Instructions:</strong> ${recipe.instructions.join("<br>")}</p>
                    </div>
                    <div class="card-footer">
                        <b>Categories:</b> ${categoriesText}
                    </div>
                </div>
            </div>`;
            container.innerHTML += card;
        });
    }
});
