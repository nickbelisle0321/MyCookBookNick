﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Xunit;
using MyCookBookAPI.Models; // Namespace for the Recipe model

namespace MyCookBook.API.Tests
{
    public class RecipeModelTests
    {

        [Fact]
        public void RecipeModel_ShouldStoreDataCorrectly()
        {
            // Arrange
            var recipe = new Recipe
            {
                Name = "Pasta",
                Ingredients = new List<string> { "Pasta", "Tomat Sauce" },
                Steps = "Boil pasta."
            };
            // Assert
            Assert.Equal("Pasta", recipe.Name);
            Assert.Contains("Tomato Sauce", recipe.Ingredients);
            Assert.Equal("Boil pasta.", recipe.Steps);
        }
    }
}
