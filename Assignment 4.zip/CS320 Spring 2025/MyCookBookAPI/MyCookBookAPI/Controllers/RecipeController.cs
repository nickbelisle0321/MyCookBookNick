﻿using Microsoft.AspNetCore.Mvc;
using MyCookBookAPI.Models;
using MyCookBookAPI.Services;
using System.Collections.Generic;

namespace MyCookBookApi.Controllers
{

    [ApiController]
    [Route("api/Recipe")]
    public class RecipeController : ControllerBase
    {
            private readonly IRecipeService _recipeService;
            public RecipeController(IRecipeService recipeService)
            {
                _recipeService = recipeService;
            }
             [HttpGet("GetAll")]
            public ActionResult<IEnumerable<Recipe>> GetAllRecipes()
             {
                var recipes = _recipeService.GetAllRecipes();

                 // Log the categories of each recipe to see the enum values being sent
                 foreach (var recipe in recipes)
                 {
                     Console.WriteLine($"Recipe: {recipe.Name}");
                     foreach (var category in recipe.Categories)
                     {
                        Console.WriteLine($"Category: {category} (Numeric value: {(int)category})");
                     }
                 }

            return Ok(recipes);
        }
        [HttpGet("{id}")]
            public ActionResult<Recipe> GetRecipeById(string id)
            {
                var recipe = _recipeService.GetRecipeById(id);
                if (recipe == null)
                {
                    return NotFound();
                }
                return Ok(recipe);
            }
            [HttpPost("search")]
            public ActionResult<IEnumerable<Recipe>> SearchRecipes([FromBody]
            RecipeSearchRequest searchRequest)
            {
                if (searchRequest == null || string.IsNullOrWhiteSpace(searchRequest.Keyword))
                {
                    return BadRequest("Invalid search request.");
                }
                // Ensure Categories is never null
                searchRequest.Categories ??= new List<CategoryType>();
                var recipes = _recipeService.SearchRecipes(searchRequest);
                return Ok(recipes);
            }
        [HttpPost("Add")]
        public ActionResult CreateRecipe([FromBody] Recipe recipe)
        {
            if (recipe == null || string.IsNullOrWhiteSpace(recipe.Name))
            {
                return BadRequest(new
                {
                    success = false,
                    message = "Invalid recipe data."
                });
            }

            // Ensure RecipeId is created in the backend
            recipe.RecipeId = Guid.NewGuid().ToString();
            _recipeService.AddRecipe(recipe);

            return Ok(new
            {
                success = true,
                message = "Recipe added successfully",
                recipe
            });
        }
    }
}
