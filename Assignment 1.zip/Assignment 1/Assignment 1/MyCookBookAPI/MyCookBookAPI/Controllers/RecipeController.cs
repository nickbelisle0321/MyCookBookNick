﻿using Microsoft.AspNetCore.Mvc;
using MyCookBookAPI.Models;
using System.Collections.Generic;

namespace MyCookBookApi.Controllers
{
    /// <summary>
    /// API controller for managing recipes.
    /// </summary>
    [Route("api/[controller]")]
    [ApiController]
    public class RecipeController : ControllerBase
    {
        /// <summary>
        /// Get a sample recipe.
        /// </summary>
        /// <returns>A static recipe object.</returns>
        [HttpGet]
        public IActionResult GetRecipe()
        {
            var recipe = new Recipe
            {
                Id = "1",
                Name = "Pancakes",
                Category = "Breakfast",
                Steps = new List<string>
                {
                    "Mix all ingredients in a bowl.",
                    "Heat a pan and pour the batter.",
                    "Cook until golden brown on both sides."
                },
                Ingredients = new List<string>
                {
                    "Flour", "Milk", "Egg", "Butter", "Sugar"
                }
            };

            return Ok(recipe);
        }
    }
}
