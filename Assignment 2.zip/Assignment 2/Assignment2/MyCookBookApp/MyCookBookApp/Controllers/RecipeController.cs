﻿using Microsoft.AspNetCore.Mvc;
using MyCookBookApp.Services;
using System.Threading.Tasks;
namespace MyCookBookApp.Controllers
{
    public class RecipeController : Controller
    {
        private readonly RecipeService _recipeService;
        public RecipeController(RecipeService recipeService)
        {
            _recipeService = recipeService;
        }
        public async Task<IActionResult> Index()
        {
            // Await the asynchronous method to get the recipes
            var recipes = await _recipeService.GetRecipesAsync(); // This returns List<MyCookBookAPI.Models.Recipe>

            // Ensure you are passing the correct type to the view
            return View(recipes);
        }
    }
}