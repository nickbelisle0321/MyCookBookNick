using Microsoft.AspNetCore.Mvc;
using MyCookBookApp.Models;
using MyCookBookApp.Services;
using System.Diagnostics;

namespace MyCookBookApp.Controllers
{
    public class HomeController : Controller
    {
        private readonly RecipeService _recipeService;

        public HomeController(RecipeService recipeService)
        {
            _recipeService = recipeService;
        }

        public async Task<IActionResult> Index()
        {
            var recipes = await _recipeService.GetRecipesAsync();  // This fetches the recipes
            return View("HomePage", recipes);  // Pass the recipes to the view
        }
    }

}
