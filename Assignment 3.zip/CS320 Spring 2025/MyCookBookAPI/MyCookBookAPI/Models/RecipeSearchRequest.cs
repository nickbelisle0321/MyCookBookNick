﻿namespace MyCookBookAPI.Models
{
    public class RecipeSearchRequest
    {
        public string Query { get; set; }
    }
}
