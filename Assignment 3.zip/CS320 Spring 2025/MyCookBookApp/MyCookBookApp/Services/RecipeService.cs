﻿using System.Net.Http;
using System.Threading.Tasks;
using Newtonsoft.Json;
using MyCookBookApp.Models;
using System.Text;
namespace MyCookBookApp.Services
{
    public class RecipeService
    {
        public async Task<List<MyCookBookApp.Models.Recipe>> SearchRecipesAsync(string query)
        {
            var payload = new { Query = query };

            // Log the payload to ensure it's correct
            var payloadJson = JsonConvert.SerializeObject(payload);
            Console.WriteLine($"Payload: {payloadJson}");

            var request = new HttpRequestMessage(HttpMethod.Post, "https://localhost:7182/api/recipe/search")
            {
                Content = new StringContent(payloadJson, Encoding.UTF8, "application/json")
            };

            request.Headers.Accept.Add(new System.Net.Http.Headers.MediaTypeWithQualityHeaderValue("application/json"));

            var response = await _httpClient.SendAsync(request);
            response.EnsureSuccessStatusCode();

            var responseString = await response.Content.ReadAsStringAsync();
            var apiRecipes = JsonConvert.DeserializeObject<List<MyCookBookAPI.Models.Recipe>>(responseString);

            // Ensure mapping from API Recipe to App Recipe
            var appRecipes = apiRecipes.Select(r => new MyCookBookApp.Models.Recipe
            {
                Name = r.Name,
                Ingredients = r.Ingredients,
                Steps = r.Steps
            }).ToList();

            return appRecipes;
        }



        private readonly HttpClient _httpClient;
        public RecipeService(HttpClient httpClient)
        {
            _httpClient = httpClient;
        }
        public async Task<List<MyCookBookAPI.Models.Recipe>> GetRecipesAsync()
        {
            var response = await _httpClient.GetAsync("https://localhost:7182/api/recipe");
            response.EnsureSuccessStatusCode();
            var json = await response.Content.ReadAsStringAsync();
            return JsonConvert.DeserializeObject<List<MyCookBookAPI.Models.Recipe>>(json);
        }
    }
}
  