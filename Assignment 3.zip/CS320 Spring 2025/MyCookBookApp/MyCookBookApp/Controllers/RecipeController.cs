﻿using Microsoft.AspNetCore.Mvc;
using MyCookBookApp.Services;
using System.Threading.Tasks;
using MyCookBookApp.Models;
namespace MyCookBookApp.Controllers
{
    public class RecipeController : Controller
    {
        private readonly RecipeService _recipeService;
        public RecipeController(RecipeService recipeService)
        {
            _recipeService = recipeService;
        }

        [HttpPost]
        public async Task<IActionResult> Search(string query)
        {
            if (string.IsNullOrWhiteSpace(query))
            {
                return RedirectToAction("Index");
            }

            var recipes = await _recipeService.SearchRecipesAsync(query);
            return View("Index", recipes);
        }

        public async Task<IActionResult> Index()
        {
            // Await the asynchronous method to get the recipes
            var apiRecipes = await _recipeService.GetRecipesAsync(); // This returns List<MyCookBookAPI.Models.Recipe>

            // Ensure you're mapping from API Recipe to App Recipe
            var appRecipes = apiRecipes.Select(r => new MyCookBookApp.Models.Recipe
            {
                Name = r.Name,
                Ingredients = r.Ingredients,
                Steps = r.Steps
            }).ToList();

            return View(appRecipes); // Pass the mapped list to the view
        }
    }
}